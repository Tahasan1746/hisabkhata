/* Public runtime configuration. Safe for the browser: only the Project URL and the PUBLIC
 * anon/publishable key belong here. Never paste a service-role or secret key.
 *
 * Either edit the two values below for local use, or leave them empty and let the deploy
 * step generate this file from environment variables (scripts/build-config.mjs).
 * With both empty, the app runs fully offline on this device, exactly as before. */
window.HISAB_CONFIG = Object.freeze({
  SUPABASE_URL: '',        // e.g. https://abcdefghijklmnop.supabase.co
  SUPABASE_ANON_KEY: '',   // e.g. the "anon public" key, or a sb_publishable_... key
});
