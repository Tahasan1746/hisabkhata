'use strict';
/* Run: npm test   (or: node --test tests/sync-core.test.js)
 * FakeServer follows the same rules as supabase/migrations/0001 and 0002:
 * per-row versions, retry-safe writes, RLS-style isolation per user, and the ledger rule.
 * The real database is covered by supabase/tests/rls_and_sync.sql (needs a Postgres/Supabase project). */
const test = require('node:test');
const assert = require('node:assert/strict');
const Core = require('../sync-core.js');

const iso = (ms) => new Date(ms).toISOString();
const uuid = () => require('node:crypto').randomUUID();

/* ---------------- a server that behaves like the SQL functions ---------------- */
class FakeServer {
  constructor() {
    this.people = new Map();
    this.txns = new Map();
    this.backups = [];
    this.clock = Date.parse('2026-10-10T00:00:00Z');
    this.offline = false;
    this.dropNextResponse = false;
  }
  now() { this.clock += 1000; return iso(this.clock); }
  visible(map, user, id) { const r = map.get(id); return r && r.user_id === user ? r : null; }

  checkLedger(user, personId, extra) {
    const rows = [...this.txns.values()].filter(r =>
      r.user_id === user && r.person_id === personId && !r.deleted_at && !r.voided && (!extra || r.id !== extra.id));
    if (extra && !extra.deleted_at && !extra.voided) rows.push(extra);
    const sum = ty => rows.filter(r => r.type === ty).reduce((s, r) => s + r.amount_paisa, 0);
    if (sum('received') > sum('lent')) throw new Error('LEDGER: বাকি পাওনার চেয়ে বেশি গ্রহণ করা যাবে না');
    if (sum('paid') > sum('borrowed')) throw new Error('LEDGER: বাকি দেনার চেয়ে বেশি পরিশোধ করা যাবে না');
  }

  applyPerson(user, ch) {
    const cur = this.visible(this.people, user, ch.id);
    const d = ch.data || {};
    const fields = { name: d.name, phone: d.phone || '', notes: d.notes || '', archived: !!d.archived };
    if (!cur) {
      if (ch.op === 'delete') return { status: 'ok', version: 0 };
      if (this.people.has(ch.id)) throw new Error('duplicate key value violates unique constraint');
      if (ch.expected !== 0) return { status: 'conflict', server: null };
      this.people.set(ch.id, { id: ch.id, user_id: user, ...fields, version: 1, created_at: d.created_at, updated_at: this.now(), deleted_at: null });
      return { status: 'ok', version: 1 };
    }
    if (ch.op === 'delete') {
      if (cur.deleted_at) return { status: 'ok', version: cur.version };
      if (cur.version !== ch.expected) return { status: 'conflict', server: { ...cur } };
      cur.deleted_at = this.now(); cur.version += 1; cur.updated_at = cur.deleted_at;
      return { status: 'ok', version: cur.version };
    }
    if (cur.version === ch.expected) {
      Object.assign(cur, fields, { deleted_at: null, version: cur.version + 1, updated_at: this.now() });
      return { status: 'ok', version: cur.version };
    }
    const same = !cur.deleted_at && cur.name === fields.name && cur.phone === fields.phone
      && cur.notes === fields.notes && cur.archived === fields.archived;
    if (same) return { status: 'ok', version: cur.version };
    return { status: 'conflict', server: { ...cur } };
  }

  applyTxn(user, ch) {
    const cur = this.visible(this.txns, user, ch.id);
    const d = ch.data || {};
    const fields = {
      person_id: d.person_id, type: d.type, amount_paisa: d.amount_paisa, txn_date: d.txn_date,
      due_date: d.due_date || null, category: d.category, note: d.note, voided: !!d.voided, audit: d.audit || [],
    };
    if (!cur) {
      if (ch.op === 'delete') return { status: 'ok', version: 0 };
      if (this.txns.has(ch.id)) throw new Error('duplicate key value violates unique constraint');
      if (ch.expected !== 0) return { status: 'conflict', server: null };
      if (!this.visible(this.people, user, fields.person_id)) throw new Error('foreign key violation');
      const row = { id: ch.id, user_id: user, ...fields, version: 1, created_at: d.created_at, updated_at: this.now(), deleted_at: null };
      this.checkLedger(user, row.person_id, row);
      this.txns.set(ch.id, row);
      return { status: 'ok', version: 1 };
    }
    if (ch.op === 'delete') {
      if (cur.deleted_at) return { status: 'ok', version: cur.version };
      if (cur.version !== ch.expected) return { status: 'conflict', server: { ...cur } };
      const cand = { ...cur, deleted_at: this.now() };
      this.checkLedger(user, cur.person_id, cand);
      Object.assign(cur, cand, { version: cur.version + 1, updated_at: cand.deleted_at });
      return { status: 'ok', version: cur.version };
    }
    if (cur.version === ch.expected) {
      const cand = { ...cur, ...fields, deleted_at: null };
      this.checkLedger(user, cand.person_id, cand);
      Object.assign(cur, cand, { version: cur.version + 1, updated_at: this.now() });
      return { status: 'ok', version: cur.version };
    }
    const same = !cur.deleted_at && cur.person_id === fields.person_id && cur.type === fields.type
      && cur.amount_paisa === fields.amount_paisa && cur.txn_date === fields.txn_date
      && cur.due_date === fields.due_date && cur.category === fields.category && cur.note === fields.note
      && cur.voided === fields.voided && JSON.stringify(cur.audit) === JSON.stringify(fields.audit);
    if (same) return { status: 'ok', version: cur.version };
    return { status: 'conflict', server: { ...cur } };
  }

  /* ---- RPC surface used by the client ---- */
  push(user, changes) {
    if (this.offline) return Promise.reject(new TypeError('Failed to fetch'));
    const results = changes.map(ch => {
      try {
        const r = ch.kind === 'person' ? this.applyPerson(user, ch) : this.applyTxn(user, ch);
        return { kind: ch.kind, id: ch.id, ...r };
      } catch (e) {
        return { kind: ch.kind, id: ch.id, status: 'error', message: e.message };
      }
    });
    if (this.dropNextResponse) {                          // the write happened, but the reply never arrives
      this.dropNextResponse = false;
      return Promise.reject(new TypeError('Failed to fetch'));
    }
    return Promise.resolve(results);
  }
  pull(user, since) {
    if (this.offline) return Promise.reject(new TypeError('Failed to fetch'));
    const after = r => Date.parse(r.updated_at) > Date.parse(since);
    const mine = m => [...m.values()].filter(r => r.user_id === user && after(r)).map(r => ({ ...r }));
    return Promise.resolve({ server_time: this.now(), people: mine(this.people), txns: mine(this.txns) });
  }
  replaceAll(user, people, txns) {
    const snap = { people: structuredClone([...this.people]), txns: structuredClone([...this.txns]) };
    try {
      for (const r of [...this.people.values(), ...this.txns.values()]) {
        if (r.user_id === user && !r.deleted_at) { r.deleted_at = this.now(); r.version += 1; }
      }
      for (const p of people) {
        const cur = this.people.get(p.id);
        if (cur && cur.user_id !== user) throw new Error('duplicate key');
        const row = { id: p.id, user_id: user, name: p.name, phone: p.phone, notes: p.notes, archived: p.archived,
          version: cur ? cur.version + 1 : 1, created_at: p.created_at, updated_at: this.now(), deleted_at: null };
        this.people.set(p.id, row);
      }
      for (const t of txns) {
        const cur = this.txns.get(t.id);
        const row = { id: t.id, user_id: user, person_id: t.person_id, type: t.type, amount_paisa: t.amount_paisa,
          txn_date: t.txn_date, due_date: t.due_date || null, category: t.category, note: t.note, voided: !!t.voided,
          audit: t.audit || [], version: cur ? cur.version + 1 : 1, created_at: t.created_at, updated_at: this.now(), deleted_at: null };
        this.txns.set(t.id, row);
      }
      for (const pid of new Set(txns.map(t => t.person_id))) this.checkLedger(user, pid, null);
      const live = m => [...m.values()].filter(r => r.user_id === user && !r.deleted_at).map(r => ({ id: r.id, version: r.version }));
      return { server_time: this.now(), people: live(this.people), txns: live(this.txns) };
    } catch (e) {
      this.people = new Map(snap.people);
      this.txns = new Map(snap.txns);
      throw e;
    }
  }
  liveCount(user) {
    return {
      people: [...this.people.values()].filter(r => r.user_id === user && !r.deleted_at).length,
      txns: [...this.txns.values()].filter(r => r.user_id === user && !r.deleted_at).length,
    };
  }
}

/* ---------------- a device: local state + the engine wired to a user's session ---------------- */
function makeDevice(server, userId) {
  const dev = { st: { people: [], txns: [], sync: Core.emptySync() } };
  dev.env = {
    getState: () => dev.st,
    commit: async (st) => { dev.st = st; },
    push: (changes) => server.push(userId, changes),
    pull: (since) => server.pull(userId, since),
  };
  dev.sync = () => Core.runSync(dev.env);
  dev.addPerson = (name) => {
    const p = Core.touch({ id: uuid(), name, phone: '', notes: '', archived: false, createdAt: iso(server.clock), updatedAt: iso(server.clock) });
    dev.st = { ...dev.st, people: [...dev.st.people, p] };
    return p;
  };
  dev.addTxn = (personId, type, amount, date, dueDate = null) => {
    const t = Core.touch({ id: uuid(), personId, type, amount, date, dueDate, category: 'ব্যক্তিগত', note: '',
      voided: false, audit: [], createdAt: iso(server.clock), updatedAt: iso(server.clock) });
    dev.st = { ...dev.st, txns: [...dev.st.txns, t] };
    return t;
  };
  dev.editTxn = (id, patch) => {
    dev.st = { ...dev.st, txns: dev.st.txns.map(t => (t.id === id ? Core.touch({ ...t, ...patch }) : t)) };
  };
  dev.txn = (id) => dev.st.txns.find(t => t.id === id);
  dev.person = (id) => dev.st.people.find(p => p.id === id);
  return dev;
}

const U1 = 'user-1';
const U2 = 'user-2';

/* ================================ mapping & change building ================================ */
test('cloud mapping round-trips person and transaction fields', () => {
  const p = { id: 'p1', name: 'রহিম', phone: '01700000001', notes: 'n', archived: true, createdAt: '2026-10-01T00:00:00Z' };
  const back = Core.fromCloudPerson({ ...Core.toCloudPerson(p), version: 3, updated_at: '2026-10-02T00:00:00Z' });
  assert.equal(back.name, 'রহিম');
  assert.equal(back.sv, 3);
  assert.equal(back.dirty, false);

  const t = { id: 't1', personId: 'p1', type: 'lent', amount: 500000, date: '2026-10-01', dueDate: '2026-10-15', category: 'ব্যবসা', note: 'x', voided: false, audit: [{ action: 'তৈরি' }], createdAt: '2026-10-01T00:00:00Z' };
  const row = { ...Core.toCloudTxn(t), version: 2, updated_at: '2026-10-02T00:00:00Z' };
  const tb = Core.fromCloudTxn(row);
  assert.equal(row.amount_paisa, 500000);
  assert.equal(tb.amount, 500000);
  assert.equal(tb.dueDate, '2026-10-15');
  assert.equal(tb.sv, 2);
});

test('buildChanges sends only dirty, non-demo, non-conflicted records in ledger-safe order', () => {
  const st = {
    people: [
      Core.touch({ id: 'pDirty', name: 'A', phone: '', notes: '', archived: false, createdAt: iso(0) }),
      { id: 'pClean', name: 'B', phone: '', notes: '', archived: false, createdAt: iso(0), sv: 1, dirty: false },
      { id: 'pDemo', name: 'D', demo: true, dirty: true, sv: 0 },
    ],
    txns: [
      Core.touch({ id: 'tRepay', personId: 'pDirty', type: 'received', amount: 100, date: '2026-10-01', audit: [] }),
      Core.touch({ id: 'tLoan', personId: 'pDirty', type: 'lent', amount: 500, date: '2026-10-01', audit: [] }),
      { id: 'tConf', personId: 'pDirty', type: 'lent', amount: 9, date: '2026-10-01', dirty: true, conflict: true, sv: 2 },
    ],
    sync: Core.emptySync({ tombs: [{ kind: 'txn', id: 'tOldRepay', type: 'paid', sv: 4 }, { kind: 'txn', id: 'tOldLoan', type: 'borrowed', sv: 4 }] }),
  };
  const changes = Core.buildChanges(st);
  const order = changes.map(c => `${c.kind}:${c.op}:${c.id}`);
  assert.deepEqual(order, [
    'person:upsert:pDirty',
    'txn:upsert:tLoan',
    'txn:upsert:tRepay',
    'txn:delete:tOldRepay',
    'txn:delete:tOldLoan',
  ]);
});

test('ensureSyncFields queues old local records for upload but never demo records', () => {
  const out = Core.ensureSyncFields([{ id: 'a' }, { id: 'b', demo: true }, { id: 'c', sv: 5, dirty: false }]);
  assert.equal(out[0].sv, 0); assert.equal(out[0].dirty, true);
  assert.equal(out[1].dirty, false);
  assert.equal(out[2].sv, 5); assert.equal(out[2].dirty, false);
});

/* ================================ happy path, offline recovery, cross-device ================================ */
test('a successful push marks records clean and stores the server version', async () => {
  const server = new FakeServer();
  const dev = makeDevice(server, U1);
  const p = dev.addPerson('রহিম');
  const res = await dev.sync();
  assert.equal(res.pushed, 1);
  assert.equal(dev.person(p.id).dirty, false);
  assert.equal(dev.person(p.id).sv, 1);
  assert.equal(server.liveCount(U1).people, 1);
});

test('offline: changes stay on the device, nothing is lost, and the sync throws a network error', async () => {
  const server = new FakeServer();
  const dev = makeDevice(server, U1);
  const p = dev.addPerson('করিম');
  dev.addTxn(p.id, 'lent', 300000, '2026-10-01');
  server.offline = true;
  await assert.rejects(dev.sync(), (e) => Core.isNetworkError(e, { onLine: true }));
  assert.equal(Core.countPending(dev.st), 2);
  assert.equal(dev.person(p.id).dirty, true);
  assert.equal(server.liveCount(U1).people, 0);
});

test('offline recovery: queued changes upload when the connection returns', async () => {
  const server = new FakeServer();
  const dev = makeDevice(server, U1);
  const p = dev.addPerson('সালমা');
  dev.addTxn(p.id, 'borrowed', 250000, '2026-10-02', '2026-10-20');
  server.offline = true;
  await assert.rejects(dev.sync());
  server.offline = false;
  const res = await dev.sync();
  assert.equal(res.pending, 0);
  assert.deepEqual(server.liveCount(U1), { people: 1, txns: 1 });
});

test('restore on a new device: it pulls the full ledger from the cloud', async () => {
  const server = new FakeServer();
  const a = makeDevice(server, U1);
  const p = a.addPerson('রহিম');
  const loan = a.addTxn(p.id, 'lent', 500000, '2026-10-01', '2026-10-15');
  await a.sync();
  const b = makeDevice(server, U1);
  await b.sync();
  assert.equal(b.st.people.length, 1);
  assert.equal(b.st.txns.length, 1);
  assert.equal(b.txn(loan.id).amount, 500000);
  assert.equal(b.txn(loan.id).dirty, false);
});

test('a partial repayment made on device B is visible on device A after it syncs', async () => {
  const server = new FakeServer();
  const a = makeDevice(server, U1);
  const p = a.addPerson('রহিম');
  a.addTxn(p.id, 'lent', 500000, '2026-10-01');
  await a.sync();
  const b = makeDevice(server, U1);
  await b.sync();
  b.addTxn(p.id, 'received', 200000, '2026-10-05');
  await b.sync();
  await a.sync();
  const received = a.st.txns.filter(t => t.type === 'received');
  assert.equal(received.length, 1);
  assert.equal(received[0].amount, 200000);
});

/* ================================ duplicates and retries ================================ */
test('a lost response does not create duplicates when the same batch is retried', async () => {
  const server = new FakeServer();
  const dev = makeDevice(server, U1);
  const p = dev.addPerson('রহিম');
  dev.addTxn(p.id, 'lent', 100000, '2026-10-01');
  server.dropNextResponse = true;
  await assert.rejects(dev.sync());
  assert.deepEqual(server.liveCount(U1), { people: 1, txns: 1 }, 'the server did apply the write');
  await dev.sync();
  assert.deepEqual(server.liveCount(U1), { people: 1, txns: 1 }, 'the retry must not duplicate');
  assert.equal(Core.countPending(dev.st), 0);
});

/* ================================ conflicts ================================ */
test('two devices edit the same record: the stale device gets a conflict and keeps its copy until it chooses', async () => {
  const server = new FakeServer();
  const a = makeDevice(server, U1);
  const p = a.addPerson('রহিম');
  const t = a.addTxn(p.id, 'lent', 500000, '2026-10-01');
  await a.sync();
  const b = makeDevice(server, U1);
  await b.sync();

  b.editTxn(t.id, { amount: 600000 });                 // B edits and syncs first
  await b.sync();

  a.editTxn(t.id, { amount: 700000 });                 // A edited offline on the old version
  await a.sync();
  const conflicts = a.st.sync.conflicts;
  assert.equal(conflicts.length, 1);
  assert.equal(conflicts[0].reason, 'remote-changed');
  assert.equal(conflicts[0].server.amount_paisa, 600000);
  assert.equal(a.txn(t.id).conflict, true);
  assert.equal(a.txn(t.id).amount, 700000, 'the local copy is never overwritten silently');
  assert.equal(server.txns.get(t.id).amount_paisa, 600000, 'the server is untouched until the user decides');

  a.st = Core.resolveConflict(a.st, conflicts[0].key, 'local');
  await a.sync();
  assert.equal(server.txns.get(t.id).amount_paisa, 700000);
  assert.equal(a.st.sync.conflicts.length, 0);
});

test('resolving a conflict with the server copy restores the cloud version on this device', async () => {
  const server = new FakeServer();
  const a = makeDevice(server, U1);
  const p = a.addPerson('রহিম');
  const t = a.addTxn(p.id, 'lent', 500000, '2026-10-01');
  await a.sync();
  const b = makeDevice(server, U1);
  await b.sync();
  b.editTxn(t.id, { amount: 600000 });
  await b.sync();
  a.editTxn(t.id, { amount: 700000 });
  await a.sync();
  const key = a.st.sync.conflicts[0].key;
  a.st = Core.resolveConflict(a.st, key, 'server');
  assert.equal(a.txn(t.id).amount, 600000);
  assert.equal(a.txn(t.id).dirty, false);
  await a.sync();
  assert.equal(server.txns.get(t.id).amount_paisa, 600000);
});

test('unchanged server rows never overwrite a pending local edit', () => {
  const local = { people: [], txns: [Core.touch({ id: 't', personId: 'p', type: 'lent', amount: 1, date: '2026-10-01', sv: 3 })], sync: Core.emptySync() };
  const pulled = { people: [], txns: [{ id: 't', person_id: 'p', type: 'lent', amount_paisa: 999, txn_date: '2026-10-01', version: 3, updated_at: '2026-10-02T00:00:00Z' }] };
  const out = Core.applyPull(local, pulled);
  assert.equal(out.txns[0].amount, 1);
  assert.equal(out.txns[0].dirty, true);
  assert.equal(out.sync.conflicts.length, 0);
});

test('a server ledger rejection is reported as a rejected conflict and nothing is stored on the server', async () => {
  const server = new FakeServer();
  const dev = makeDevice(server, U1);
  const p = dev.addPerson('রহিম');
  dev.addTxn(p.id, 'lent', 500000, '2026-10-01');
  await dev.sync();
  dev.addTxn(p.id, 'received', 600000, '2026-10-03');       // more than is owed
  await dev.sync();
  const c = dev.st.sync.conflicts[0];
  assert.equal(c.reason, 'rejected');
  assert.match(c.message, /LEDGER/);
  assert.equal(server.liveCount(U1).txns, 1);
  assert.equal(dev.st.txns.find(t => t.type === 'received').conflict, true);
});

test('discarding a rejected change removes it from this device without touching the cloud', async () => {
  const server = new FakeServer();
  const dev = makeDevice(server, U1);
  const p = dev.addPerson('রহিম');
  dev.addTxn(p.id, 'lent', 500000, '2026-10-01');
  await dev.sync();
  const bad = dev.addTxn(p.id, 'received', 600000, '2026-10-03');
  await dev.sync();
  dev.st = Core.resolveConflict(dev.st, dev.st.sync.conflicts[0].key, 'server');
  assert.equal(dev.txn(bad.id), undefined, 'a never-synced record is simply discarded');
  await dev.sync();
  assert.equal(server.liveCount(U1).txns, 1);
});

/* ================================ deletions and reset ================================ */
test('a reset on one device deletes the synced data on other devices', async () => {
  const server = new FakeServer();
  const a = makeDevice(server, U1);
  const p = a.addPerson('রহিম');
  a.addTxn(p.id, 'lent', 500000, '2026-10-01');
  await a.sync();
  const b = makeDevice(server, U1);
  await b.sync();

  a.st = { ...a.st, sync: Core.tombsForReset(a.st.people, a.st.txns, a.st.sync), people: [], txns: [] };
  await a.sync();
  await b.sync();
  assert.deepEqual(server.liveCount(U1), { people: 0, txns: 0 });
  assert.equal(b.st.people.length, 0);
  assert.equal(b.st.txns.length, 0);
});

test('deleting a record that another device has changed creates a delete conflict', async () => {
  const server = new FakeServer();
  const a = makeDevice(server, U1);
  const p = a.addPerson('রহিম');
  await a.sync();
  const b = makeDevice(server, U1);
  await b.sync();
  b.st = { ...b.st, people: b.st.people.map(x => Core.touch({ ...x, name: 'রহিম (নতুন)' })) };
  await b.sync();

  a.st = { ...a.st, sync: Core.tombsForReset(a.st.people, a.st.txns, a.st.sync), people: [] };
  await a.sync();
  const c = a.st.sync.conflicts.find(x => x.id === p.id);
  assert.ok(c, 'a delete conflict is recorded');
  assert.equal(c.op, 'delete');
  a.st = Core.resolveConflict(a.st, c.key, 'server');
  assert.equal(a.st.people.length, 1, 'taking the cloud version brings the person back');
  assert.equal(a.st.people[0].name, 'রহিম (নতুন)');
});

/* ================================ data isolation ================================ */
test('users never see or modify each other\'s rows', async () => {
  const server = new FakeServer();
  const alice = makeDevice(server, U1);
  const bob = makeDevice(server, U2);
  const p = alice.addPerson('রহিম');
  await alice.sync();

  await bob.sync();
  assert.equal(bob.st.people.length, 0, 'bob pulls nothing of alice');

  const hijack = await server.push(U2, [{ kind: 'person', id: p.id, op: 'upsert', expected: 1,
    data: { name: 'হ্যাক', phone: '', notes: '', archived: false } }]);
  assert.equal(hijack[0].status, 'error', 'bob cannot update alice\'s row');
  assert.equal(server.people.get(p.id).name, 'রহিম');

  const del = await server.push(U2, [{ kind: 'person', id: p.id, op: 'delete', expected: 1 }]);
  assert.equal(del[0].version, 0, 'bob cannot delete alice\'s row');
  assert.equal(server.people.get(p.id).deleted_at, null);
});

/* ================================ restore from cloud backup (replace-all) ================================ */
test('replace-all restores exactly the backup and soft-deletes anything not in it', async () => {
  const server = new FakeServer();
  const a = makeDevice(server, U1);
  const keep = a.addPerson('রহিম');
  const extra = a.addPerson('অতিরিক্ত');
  await a.sync();

  const payload = Core.buildPayload([keep], [], iso(server.clock));
  const versions = server.replaceAll(U1, payload.people, payload.txns);
  a.st = Core.stateAfterReplace(payload.people, payload.txns, versions, versions.server_time, a.st.sync);

  assert.equal(a.st.people.length, 1);
  assert.equal(a.st.people[0].dirty, false);
  // soft delete bumps the version (+1), the upsert bumps it again (+1): 1 -> 3
  assert.equal(a.st.people[0].sv, 3, 'the version comes from the server response');
  assert.equal(a.st.sync.conflicts.length, 0);

  const b = makeDevice(server, U1);
  await b.sync();
  assert.deepEqual(b.st.people.map(p => p.id), [keep.id], 'the extra person was removed everywhere');
  assert.equal(server.people.get(extra.id).deleted_at !== null, true);
});

test('replace-all that breaks the ledger rule is rolled back completely', () => {
  const server = new FakeServer();
  const personId = uuid();
  const payload = {
    people: [{ id: personId, name: 'রহিম', phone: '', notes: '', archived: false, created_at: iso(0) }],
    txns: [{ id: uuid(), person_id: personId, type: 'received', amount_paisa: 100, txn_date: '2026-10-01',
      category: 'ব্যক্তিগত', note: '', voided: false, audit: [], created_at: iso(0) }],
  };
  assert.throws(() => server.replaceAll(U1, payload.people, payload.txns), /LEDGER/);
  assert.equal(server.liveCount(U1).people, 0, 'nothing from the failed payload was kept');
});

/* ================================ key safety ================================ */
const jwt = (payload) => `eyJhbGciOiJIUzI1NiJ9.${Buffer.from(JSON.stringify(payload)).toString('base64url')}.sig`;

test('the browser accepts the public anon key and refuses the service-role key', () => {
  assert.equal(Core.assertPublicKey(jwt({ role: 'anon', iss: 'supabase' })), true);
  assert.equal(Core.assertPublicKey('sb_publishable_example123'), true);
  assert.throws(() => Core.assertPublicKey(jwt({ role: 'service_role' })), /সার্ভিস-রোল/);
  assert.throws(() => Core.assertPublicKey('sb_secret_example123'), /সার্ভিস-রোল/);
  assert.throws(() => Core.assertPublicKey(''), /কী পাওয়া যায়নি/);
});

test('backup checksums do not depend on key order', async () => {
  const a = { app: 'hisabkhata', version: 1, people: [{ id: 'x', name: 'রহিম', archived: false }] };
  const b = { people: [{ archived: false, name: 'রহিম', id: 'x' }], version: 1, app: 'hisabkhata' };
  assert.equal(await Core.checksumOf(a), await Core.checksumOf(b));
  assert.notEqual(await Core.checksumOf(a), await Core.checksumOf({ ...a, version: 2 }));
});

test('buildPayload never includes demo records or sync bookkeeping', () => {
  const payload = Core.buildPayload(
    [{ id: 'p', name: 'রহিম', demo: false, dirty: true, sv: 2, rev: 3 }, { id: 'd', name: 'ডেমো', demo: true }],
    [], '2026-10-10T00:00:00Z');
  assert.equal(payload.people.length, 1);
  assert.equal(payload.people[0].dirty, undefined);
  assert.equal(payload.people[0].sv, undefined);
});

/* ================================ engine batching ================================ */
test('large queues are split into batches and every batch is committed', async () => {
  const server = new FakeServer();
  const dev = makeDevice(server, U1);
  for (let i = 0; i < 230; i++) dev.addPerson('ব্যক্তি ' + i);
  const res = await dev.sync();
  assert.equal(res.pushed, 230);
  assert.equal(server.liveCount(U1).people, 230);
  assert.equal(Core.countPending(dev.st), 0);
});
